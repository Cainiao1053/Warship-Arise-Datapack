function loadChunks(chunk1,chunk2,chunk3,chunk4)
local loadChunk1 = "forceload add "..chunk1[1].." "..chunk1[2]
local loadChunk2 = "forceload add "..chunk2[1].." "..chunk2[2]
local loadChunk3 = "forceload add "..chunk3[1].." "..chunk3[2]
local loadChunk4 = "forceload add "..chunk4[1].." "..chunk4[2]
exec(loadChunk1);
exec(loadChunk2);
exec(loadChunk3);
exec(loadChunk4);
print(loadChunk1)
end

function unloadChunks(chunk1,chunk2,chunk3,chunk4)
local unloadChunk1 = "forceload remove "..chunk1[1].." "..chunk1[2];
local unloadChunk2 = "forceload remove "..chunk2[1].." "..chunk2[2];
local unloadChunk3 = "forceload remove "..chunk3[1].." "..chunk3[2];
local unloadChunk4 = "forceload remove "..chunk4[1].." "..chunk4[2];
exec(unloadChunk1);
exec(unloadChunk2);
exec(unloadChunk3);
exec(unloadChunk4);
end

-- change file name to startup.lua
sleep(1);
local c = peripheral.find("computer");
local g = peripheral.find("createbigcannons:cannon_mount")
if g == nil then
    os.reboot();
end
local x = g.getX()
local z = g.getZ()

local playerInfo = "tellraw @a[distance=..250] [{\"text\":\"Warning! You have been spotted from:\",\"color\":\"red\"},{\"text\":\""..x..","..z.."\",\"color\":\"gold\"}]"

local chunk1 = {math.floor(x+8),math.floor(z+8)};
local chunk2 = {math.floor(x+8),math.floor(z-8)};
local chunk3 = {math.floor(x-8),math.floor(z+8)};
local chunk4 = {math.floor(x-8),math.floor(z-8)};


loadChunks(chunk1,chunk2,chunk3,chunk4)
m = peripheral.find("modem")
m.open(508)
rednet.open(peripheral.getName(m))
local loaded = 1;

if c.isOn() == false then
    shell.run("delete disk/114516c.lua");
    shell.run("copy rom/cannoncpt/114516c.lua disk/114516c.lua");
    shell.run("delete disk/droprangelimittable.lua");
    shell.run("copy rom/cannontable/droprangelimittable.lua disk/droprangelimittable.lua");
    shell.run("delete disk/errordroptable.lua");
    shell.run("copy rom/cannontable/errordroptable.lua disk/errordroptable.lua");
    shell.run("delete disk/errorflattable.lua");
    shell.run("copy rom/cannontable/errorflattable.lua disk/errorflattable.lua");
    shell.run("delete disk/flatrangelimittable.lua");
    shell.run("copy rom/cannontable/flatrangelimittable.lua disk/flatrangelimittable.lua");
    shell.run("delete disk/maindroptable.lua");
    shell.run("copy rom/cannontable/maindroptable.lua disk/maindroptable.lua");
    shell.run("delete disk/mainflattable.lua");
    shell.run("copy rom/cannontable/mainflattable.lua disk/mainflattable.lua");
    shell.run("delete disk/startup.lua");
    shell.run("copy rom/cannoncpt/114516s.lua disk/startup.lua");
    print(1)
    sleep(0.5);
end

c.reboot()
exec(playerInfo);

while true do

    local id, cmdrcv = rednet.receive(nil,25)
    if cmdrcv ==nil then
        unloadChunks(chunk1,chunk2,chunk3,chunk4)
        loaded = 0;
    elseif cmdrcv == 1 and loaded == 0 then
        loadChunks(chunk1,chunk2,chunk3,chunk4)
        loaded = 1;
        print(1)
    else
        print(2)
    end
end